pip3 install mythril

docker pull mythril/myth

myth -x erc20.sol

npm install --save -g solgraph

solgraph contract.sol > contract.dot

npm install -g solium

npm install -g solhint