git clone https://github.com/cubedro/eth-netstats
sudo npm install -g grunt-cli
cd eth-netstats 
npm install
grunt
npm start