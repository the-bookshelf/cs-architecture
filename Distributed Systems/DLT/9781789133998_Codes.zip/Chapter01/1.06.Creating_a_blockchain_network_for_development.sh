npm install -g ganache-cli
ganache-cli
ganache-cli -a 5 -e 2000 -p 8080 -l 999999
