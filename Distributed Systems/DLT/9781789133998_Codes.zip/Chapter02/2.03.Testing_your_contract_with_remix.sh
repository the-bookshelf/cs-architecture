# Install remixd
npm install -g remixd

# Sharing files
remixd -s <Path-to-the-folder>