Internet of Things with Python

Chapter 1 has No code because its all about the features included in the Intel Galileo Gen 2 board.

Chapter 2 has No code as its all about setting up environment.