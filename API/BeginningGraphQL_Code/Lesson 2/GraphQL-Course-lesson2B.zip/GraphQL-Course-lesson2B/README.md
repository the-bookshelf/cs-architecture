# GraphQL-Course
A complete beginner to intermediate GraphQL course.

## Branches

- **lesson1** - Query and Mutation implementation. Code under `packages/server/server.js`
- **lesson2A** - Code refactor into different files. Code under `packages/server`
- **lesson2B** - Implementation for Subscription. Code under `packages/server`