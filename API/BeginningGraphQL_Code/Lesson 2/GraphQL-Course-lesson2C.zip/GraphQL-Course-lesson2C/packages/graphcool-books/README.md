## Graphcool

Source code for implementing GraphQL using Graphcool(`graphcool`)