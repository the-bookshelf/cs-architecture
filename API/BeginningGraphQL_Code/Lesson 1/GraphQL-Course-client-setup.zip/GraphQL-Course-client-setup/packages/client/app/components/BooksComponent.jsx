import React, { Component } from 'react';
import { connect } from 'react-redux';
import {List, ListItem} from 'material-ui/List';

export default class ItemList extends Component {
    constructor(props){
        super(props);
    }

    render() {
        return <div> Books Component </div>
    }
}