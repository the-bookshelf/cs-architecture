## Graphcool

Source code for implementing GraphQL server using Express and helper packages from Apollo(`graphql-server-express`)