# Lesson3A

> **Lesson3A** - setup a simple React application, connect with GraphQL client and display a list of books.