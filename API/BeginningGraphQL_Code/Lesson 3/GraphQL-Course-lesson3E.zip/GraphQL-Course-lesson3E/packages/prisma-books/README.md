## Prisma

Course code for books app using Prisma