## Graphcool

Source code for implementing GraphQL server using `graphql-yoga`